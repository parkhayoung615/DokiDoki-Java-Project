# RPG [WIP]
<p>
A small rpg prototype that I am working on using Java. This project utilizes the JavaFX library for handling the graphics.
</p>

### Things you need:
- This
- Java 8 (I am currently using jdk1.8.0_112)
- You can use any IDE you want, but <em>I recommend</em> [JetBrain's IntelliJ IDEA](https://www.jetbrains.com/idea/) for developing your projects. It's a very awesome IDE and I just love using it.
